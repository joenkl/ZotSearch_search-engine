Install node_modules:
	+ npm install at root folder
	+ cd client (goes into client and install client)
	+ npm install
