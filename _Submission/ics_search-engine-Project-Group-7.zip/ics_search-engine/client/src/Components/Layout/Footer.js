import React from "react";

export default () => {
  return (
    <div>
      <footer className="footer bg-dark text-white mt-5 p-4 text-center">
        Copyright &copy;2018 Zot Search : Joseph Nguyen - Tri Dao - Kha Bui
      </footer>
    </div>
  );
};
