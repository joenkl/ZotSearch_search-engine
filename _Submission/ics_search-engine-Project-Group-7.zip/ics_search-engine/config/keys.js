module.exports = {
  mongoURI: "mongodb://admin:jnguyen@206.189.76.194:27017/icssearch"
};

// module.exports = {
//   mongoURI: "mongodb://localhost:27017/icssearch"
// };
